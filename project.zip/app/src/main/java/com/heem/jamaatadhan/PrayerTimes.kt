package com.heem.jamaatadhan

import kotlin.math.*

// Offline waqt calculation. Fajr/Isha 18 degrees (Karachi method), Asr shadow factor 2 (Hanafi).
object PT {
    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun fix(a: Double, n: Double) = a - n * floor(a / n)

    // returns local-clock hours: fajr, sunrise, dhuhr, asr, maghrib, isha
    fun compute(lat: Double, lon: Double, y: Int, m: Int, d: Int, tz: Double): DoubleArray {
        var yy = y
        var mm = m
        if (mm <= 2) { yy -= 1; mm += 12 }
        val a = floor(yy / 100.0)
        val b = 2 - a + floor(a / 4)
        val jd = floor(365.25 * (yy + 4716)) + floor(30.6001 * (mm + 1)) + d + b - 1524.5 - lon / 360.0
        val dd = jd + 0.5 - 2451545.0
        val g = fix(357.529 + 0.98560028 * dd, 360.0)
        val q = fix(280.459 + 0.98564736 * dd, 360.0)
        val l = fix(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)), 360.0)
        val e = 23.439 - 0.00000036 * dd
        val ra = fix(deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15, 24.0)
        val eqt = q / 15 - ra
        val decl = asin(sin(rad(e)) * sin(rad(l)))
        val dhuhr = fix(12 - eqt, 24.0) + tz - lon / 15
        val la = rad(lat)
        fun t(angle: Double): Double {
            val v = (-sin(rad(angle)) - sin(la) * sin(decl)) / (cos(la) * cos(decl))
            return deg(acos(v.coerceIn(-1.0, 1.0))) / 15
        }
        val asrAngle = deg(atan(1.0 / (2 + tan(abs(la - decl)))))
        return doubleArrayOf(dhuhr - t(18.0), dhuhr - t(0.833), dhuhr, dhuhr + t(-asrAngle), dhuhr + t(0.833), dhuhr + t(18.0))
    }
}
