package com.heem.jamaatadhan

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

// Saves a crash report so the next launch can show it
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("crash", MODE_PRIVATE).edit()
                    .putString("log", android.util.Log.getStackTraceString(e).take(3000)).commit()
            } catch (x: Throwable) { }
            old?.uncaughtException(t, e)
        }
    }
}

fun bn(s: String): String = s.map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")
fun bn(n: Int): String = bn(n.toString())

fun fmtMin(m: Int): String {
    val x = ((m % 1440) + 1440) % 1440
    var h = (x / 60) % 12
    if (h == 0) h = 12
    return bn(String.format(Locale.US, "%d:%02d", h, x % 60)) + (if (x < 720) " AM" else " PM")
}

fun fmtH(h: Double) = fmtMin((h * 60).roundToInt())

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var hero: Hero
    private lateinit var locTv: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var times = DoubleArray(6)
    private var dayKey = -1
    private var first = true
    private val pi = intArrayOf(0, -1, 1, 2, 3, 4) // segment -> prayer index (-1 = no fard waqt)
    private val audioReq = 7

    private val tick = object : Runnable {
        override fun run() {
            if (Calendar.getInstance().get(Calendar.DAY_OF_YEAR) != dayKey) render() else updateHero()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#05201A")
        window.navigationBarColor = Color.parseColor("#041812")
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val root = FrameLayout(this)
        root.addView(PatternBg(this))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(30), dp(16), dp(40))
        box.addView(tv("بسم الله الرحمن الرحيم", 18f, GOLD, serif = true).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(MATCH, WRAP))
        box.addView(tv("নামাজের সময়সূচি", 28f, PARCH, bold = true, serif = true).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        locTv = tv("", 12f, MUTED).apply { gravity = Gravity.CENTER }
        box.addView(locTv, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        box.addView(chip("লোকেশন থেকে ওয়াক্ত আপডেট") { askLocation() },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(10); gravity = Gravity.CENTER_HORIZONTAL })
        hero = Hero(this)
        box.addView(hero, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        box.addView(list, LinearLayout.LayoutParams(MATCH, WRAP))
        sv.addView(box)
        root.addView(sv)
        setContentView(root)
        showCrashIfAny()
    }

    override fun onResume() {
        super.onResume()
        render()
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1000)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    // ---------- waqt logic ----------
    private fun lat() = Store.p(this).getFloat("lat", 23.8103f).toDouble()
    private fun lon() = Store.p(this).getFloat("lon", 90.4125f).toDouble()

    private fun timesFor(off: Int): DoubleArray {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, off)
        val tz = TimeZone.getDefault().getOffset(c.timeInMillis) / 3600000.0
        return PT.compute(lat(), lon(), c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), tz)
    }

    // 18 boundaries (yesterday, today, tomorrow): fajr, sunrise, dhuhr, asr, maghrib, isha
    private fun bounds(): LongArray {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        val m0 = c.timeInMillis
        val out = LongArray(18)
        for (d in -1..1) {
            val t = timesFor(d)
            for (k in 0..5) out[(d + 1) * 6 + k] = m0 + d * 86400000L + (t[k] * 3600000).toLong()
        }
        return out
    }

    private fun seg(b: LongArray, now: Long): Int {
        var k = 0
        while (k < 16 && now >= b[k + 1]) k++
        return k
    }

    private fun dur(s: Long): String {
        val h = (s / 3600).toInt()
        val m = ((s % 3600) / 60).toInt()
        val x = (s % 60).toInt()
        return if (h > 0) "${bn(h)} ঘণ্টা ${bn(m)} মিনিট" else "${bn(m)} মিনিট ${bn(x)} সেকেন্ড"
    }

    private fun clock(ms: Long): String {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        return fmtMin(c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE))
    }

    private fun updateHero() {
        val b = bounds()
        val now = System.currentTimeMillis()
        val k = seg(b, now)
        val lab = k % 6
        val p = pi[lab]
        val left = (b[k + 1] - now) / 1000
        hero.progress = ((now - b[k]).toFloat() / (b[k + 1] - b[k])).coerceIn(0f, 1f)
        hero.title = if (p < 0) "ফরজ নামাজের ওয়াক্ত নেই" else "${NAMES[p]} এর ওয়াক্ত চলছে"
        hero.sub = (if (p < 0) "জোহর শুরু হতে " else "ওয়াক্ত শেষ হতে ") + dur(left) + " বাকি"
        val nl = if (lab <= 1) 2 else (lab + 1) % 6
        val ns = if (lab == 0) b[k + 2] else b[k + 1]
        hero.next = "পরের ওয়াক্ত: ${NAMES[pi[nl]]} · ${clock(ns)}"
        val sr = b[7]; val zw = b[8]; val mg = b[10]
        hero.warn = when {
            now >= sr && now < sr + 900000L -> "এখন নামাজ নিষিদ্ধ সময় (সূর্যোদয়)"
            now >= zw - 360000L && now < zw -> "এখন নামাজ নিষিদ্ধ সময় (ঠিক দুপুর)"
            now >= mg - 900000L && now < mg -> "এখন নফল নামাজ নিষিদ্ধ সময় (সূর্যাস্ত)"
            else -> ""
        }
        hero.invalidate()
    }

    // ---------- UI ----------
    private fun render() {
        dayKey = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        times = timesFor(0)
        val loc = Store.p(this).getString("loc", "ঢাকা (ডিফল্ট)")
        locTv.text = "$loc · ${bn(String.format(Locale.US, "%.2f", lat()))}°উ ${bn(String.format(Locale.US, "%.2f", lon()))}°পূ"
        val b = bounds()
        val cur = pi[seg(b, System.currentTimeMillis()) % 6]
        list.removeAllViews()
        for (i in 0..4) list.addView(prayerCard(i, i == cur))
        list.addView(forbiddenCard())
        list.addView(toolsCard())
        Scheduler.scheduleAll(this)
        updateHero()
        if (first) { first = false; animateIn() }
    }

    private fun animateIn() {
        hero.alpha = 0f; hero.scaleX = 0.94f; hero.scaleY = 0.94f
        hero.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(DecelerateInterpolator()).start()
        for (i in 0 until list.childCount) {
            val v = list.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(30).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(250L + i * 90L).setDuration(550)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun tint(sw: Switch) {
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(st, intArrayOf(GOLD, Color.parseColor("#7A8F86")))
        sw.trackTintList = ColorStateList(st, intArrayOf(Color.parseColor("#66D4AF37"), Color.parseColor("#33FFFFFF")))
    }

    private fun prayerCard(i: Int, cur: Boolean): View {
        val c = cardView(cur)
        val st = times[intArrayOf(0, 2, 3, 4, 5)[i]]
        val en = if (i == 4) timesFor(1)[0] else times[intArrayOf(1, 3, 4, 5, 0)[i]]
        val j = Store.jamaat(this, i)
        val g = Store.gap(this, i)
        val on = Store.enabled(this, i)
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(tv(NAMES[i] + (if (cur) "  ● চলছে" else ""), 22f, if (cur) GOLD else PARCH, bold = true, serif = true))
        left.addView(tv("ওয়াক্ত: ${fmtH(st)} – ${fmtH(en)}", 12f, MUTED))
        top.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = on
        tint(sw)
        sw.setOnCheckedChangeListener { _, v ->
            Store.p(this).edit().putBoolean("e$i", v).apply()
            render()
        }
        top.addView(sw)
        c.addView(top)
        c.addView(tv("জামাত  ${fmtMin(j)}", 18f, PARCH, serif = true).apply { setPadding(0, dp(12), 0, 0) })
        c.addView(tv(
            if (on) "আজান ${fmtMin(j - g)} · জামাতের ${bn(g)} মিনিট আগে" else "আজান বন্ধ — জামাতের সময় দিলে চালু হবে",
            13f, if (on) GREEN else MUTED
        ))
        c.addView(row(chip("জামাত সময় দাও") { pickTime(i) }, chip("গ্যাপ বদলাও") { gapDialog(i) }))
        return c
    }

    private fun forbiddenCard(): View {
        val c = cardView(false)
        c.addView(tv("নিষিদ্ধ সময় (প্রায়)", 17f, RED, bold = true, serif = true))
        fun line(n: String, a: Double, b: Double) {
            c.addView(tv("$n   ${fmtH(a)} – ${fmtH(b)}", 13f, PARCH).apply { setPadding(0, dp(6), 0, 0) })
        }
        line("সূর্যোদয়", times[1], times[1] + 0.25)
        line("ঠিক দুপুর", times[2] - 0.1, times[2])
        line("সূর্যাস্ত", times[4] - 0.25, times[4])
        return c
    }

    private fun toolsCard(): View {
        val c = cardView(false)
        c.addView(tv("সেটিংস ও টুলস", 17f, GOLD, bold = true, serif = true))
        c.addView(row(
            chip(if (Store.audio(this) != null) "আজান অডিও বদলাও" else "আজান অডিও বাছাই") { pickAudio() },
            chip("আজান টেস্ট") { safe { startForegroundService(Intent(this, AdhanService::class.java)) } }
        ))
        c.addView(row(
            chip("আজান থামাও") { safe { startService(Intent(this, AdhanService::class.java).setAction("STOP")) } },
            chip("ব্যাটারি সেটিং") {
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) { appSettings() }
            }
        ))
        c.addView(row(chip("অ্যাপ সেটিং (Autostart চালু করো)") { appSettings() }))
        return c
    }

    private fun appSettings() = safe {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun safe(f: () -> Unit) {
        try { f() } catch (e: Exception) { toast("সমস্যা: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun pickTime(i: Int) {
        val j = Store.jamaat(this, i)
        TimePickerDialog(this, { _, hh, mm ->
            Store.p(this).edit().putInt("j$i", hh * 60 + mm).putBoolean("e$i", true).apply()
            render()
        }, j / 60, j % 60, false).show()
    }

    private fun gapDialog(i: Int) {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(Store.gap(this, i).toString())
        AlertDialog.Builder(this)
            .setTitle("${NAMES[i]}: জামাতের কত মিনিট আগে আজান?")
            .setView(e)
            .setPositiveButton("Save") { _, _ ->
                val v = e.text.toString().toIntOrNull()
                if (v != null) {
                    Store.p(this).edit().putInt("g$i", v.coerceIn(0, 180)).apply()
                    render()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- location ----------
    private fun askLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) fetchLocation()
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 2)
    }

    @Suppress("DEPRECATION")
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(rc, p, g)
        if (rc == 2 && g.any { it == PackageManager.PERMISSION_GRANTED }) fetchLocation()
    }

    private fun saveLoc(l: Location) {
        Store.p(this).edit().putFloat("lat", l.latitude.toFloat()).putFloat("lon", l.longitude.toFloat())
            .putString("loc", "আপনার বর্তমান লোকেশন").apply()
        toast("লোকেশন অনুযায়ী ওয়াক্ত আপডেট হয়েছে")
        render()
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun fetchLocation() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best.time) best = l
            }
            if (best != null) { saveLoc(best); return }
            val prov = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (prov == null) { toast("ফোনের Location (GPS) চালু করে আবার চেষ্টা করো"); return }
            toast("লোকেশন খোঁজা হচ্ছে...")
            lm.requestSingleUpdate(prov, object : LocationListener {
                override fun onLocationChanged(l: Location) { saveLoc(l) }
                override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
            }, Looper.getMainLooper())
        } catch (e: Exception) {
            toast("লোকেশন পাওয়া যায়নি: ${e.message}")
        }
    }

    // ---------- audio picker & crash report ----------
    private fun pickAudio() {
        val it = Intent(Intent.ACTION_OPEN_DOCUMENT)
        it.addCategory(Intent.CATEGORY_OPENABLE)
        it.type = "audio/*"
        it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        safe { startActivityForResult(it, audioReq) }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val u = d?.data
        if (r == audioReq && res == RESULT_OK && u != null) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
            Store.p(this).edit().putString("audio", u.toString()).apply()
            render()
        }
    }

    private fun showCrashIfAny() {
        val sp = getSharedPreferences("crash", MODE_PRIVATE)
        val log = sp.getString("log", null) ?: return
        sp.edit().remove("log").apply()
        AlertDialog.Builder(this)
            .setTitle("আগের বার অ্যাপ crash করেছিল")
            .setMessage(log.take(1200))
            .setPositiveButton("Copy") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", log))
            }
            .setNegativeButton("Close", null)
            .show()
    }
}
