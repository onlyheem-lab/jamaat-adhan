package com.heem.jamaatadhan

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.*
import java.util.Calendar

val NAMES = listOf("ফজর", "জোহর", "আসর", "মাগরিব", "ইশা")
val DEF_J = intArrayOf(5 * 60, 13 * 60 + 30, 16 * 60 + 30, 18 * 60 + 10, 20 * 60)
val DEF_G = intArrayOf(15, 30, 15, 3, 15)

object Store {
    fun p(c: Context): SharedPreferences = c.getSharedPreferences("jamaat", Context.MODE_PRIVATE)
    fun jamaat(c: Context, i: Int) = p(c).getInt("j$i", DEF_J[i])
    fun gap(c: Context, i: Int) = p(c).getInt("g$i", DEF_G[i])
    fun enabled(c: Context, i: Int) = p(c).getBoolean("e$i", false)
    fun audio(c: Context): String? = p(c).getString("audio", null)
}

object Scheduler {
    // আজানের সময় = জামাতের সময় - gap
    fun triggerTime(c: Context, i: Int): Long {
        val j = Store.jamaat(c, i)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, j / 60)
        cal.set(Calendar.MINUTE, j % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.MINUTE, -Store.gap(c, i))
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun pending(c: Context, i: Int): PendingIntent {
        val intent = Intent(c, AlarmReceiver::class.java).putExtra("i", i)
        return PendingIntent.getBroadcast(c, i, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun scheduleAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0..4) {
            if (Store.enabled(c, i)) {
                val show = PendingIntent.getActivity(c, 100 + i, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerTime(c, i), show), pending(c, i))
            } else {
                am.cancel(pending(c, i))
            }
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val i = intent.getIntExtra("i", -1)
        c.startForegroundService(Intent(c, AdhanService::class.java).putExtra("i", i))
        Scheduler.scheduleAll(c) // পরের দিনের জন্য আবার সেট
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        Scheduler.scheduleAll(c)
    }
}

class AdhanService : Service() {
    private var player: MediaPlayer? = null
    private var oldVol = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        val i = intent?.getIntExtra("i", -1) ?: -1
        val name = if (i in 0..4) NAMES[i] else "আজান"
        val ch = "adhan"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Adhan", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, AdhanService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("$name এর আজান")
            .setContentText("থামাতে Stop চাপো")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)

        val am = getSystemService(AudioManager::class.java)
        if (oldVol < 0) oldVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)

        player?.release()
        val uri = Store.audio(this)?.let { Uri.parse(it) } ?: Settings.System.DEFAULT_ALARM_ALERT_URI
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setWakeMode(this@AdhanService, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(this@AdhanService, uri)
                setOnCompletionListener { stopSelf() }
                prepare()
                start()
            }
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        player?.release()
        player = null
        if (oldVol >= 0) {
            getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, oldVol, 0)
        }
        super.onDestroy()
    }
}

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private val audioReq = 7

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#0f1115"))
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(32), dp(16), dp(32))
        sv.addView(box)
        setContentView(sv)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun fmt(m: Int): String {
        val x = ((m % 1440) + 1440) % 1440
        var h = (x / 60) % 12
        if (h == 0) h = 12
        return "%d:%02d %s".format(h, x % 60, if (x < 720) "AM" else "PM")
    }

    private fun tv(t: String, size: Float, color: String = "#ffffff", bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { f() }
    }

    private fun render() {
        box.removeAllViews()
        box.addView(tv("জামাত আজান", 26f, bold = true))
        box.addView(tv("জামাতের সময় দাও, তার আগে ফুল ভলিউমে আজান বাজবে", 13f, "#9aa0a6"))
        val hasAudio = Store.audio(this) != null
        box.addView(btn(if (hasAudio) "আজানের অডিও বদলাও (বাছাই করা আছে)" else "আজানের অডিও বাছাই করো (এখন: ডিফল্ট অ্যালার্ম)") { pickAudio() })
        box.addView(btn("এখনই আজান টেস্ট করো") { startForegroundService(Intent(this, AdhanService::class.java)) })
        box.addView(btn("আজান থামাও") { startService(Intent(this, AdhanService::class.java).setAction("STOP")) })
        box.addView(btn("ব্যাটারি সেটিং (অ্যাপকে Unrestricted করো)") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        box.addView(btn("অ্যাপ সেটিং (Autostart চালু করো)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        for (i in 0..4) box.addView(card(i))
        Scheduler.scheduleAll(this)
    }

    private fun card(i: Int): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setBackgroundColor(Color.parseColor("#1b1f27"))
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        c.layoutParams = lp
        val j = Store.jamaat(this, i)
        val g = Store.gap(this, i)
        val on = Store.enabled(this, i)
        c.addView(tv(NAMES[i], 20f, bold = true))
        c.addView(tv("জামাত: ${fmt(j)}", 16f))
        c.addView(tv(if (on) "আজান: ${fmt(j - g)} ($g মিনিট আগে)" else "বন্ধ আছে — জামাতের সময় দিলে চালু হবে", 14f, if (on) "#7ddc8a" else "#9aa0a6"))
        val row = LinearLayout(this)
        row.gravity = android.view.Gravity.CENTER_VERTICAL
        row.addView(btn("জামাত সময়") {
            TimePickerDialog(this, { _, h, m ->
                Store.p(this).edit().putInt("j$i", h * 60 + m).putBoolean("e$i", true).apply()
                render()
            }, j / 60, j % 60, false).show()
        })
        row.addView(btn("গ্যাপ") { gapDialog(i) })
        val sw = Switch(this)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, v ->
            Store.p(this).edit().putBoolean("e$i", v).apply()
            render()
        }
        row.addView(sw)
        c.addView(row)
        return c
    }

    private fun gapDialog(i: Int) {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(Store.gap(this, i).toString())
        AlertDialog.Builder(this)
            .setTitle("${NAMES[i]}: জামাতের কত মিনিট আগে আজান?")
            .setView(e)
            .setPositiveButton("Save") { _, _ ->
                val v = e.text.toString().toIntOrNull()
                if (v != null) {
                    Store.p(this).edit().putInt("g$i", v.coerceIn(0, 180)).apply()
                    render()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickAudio() {
        val it = Intent(Intent.ACTION_OPEN_DOCUMENT)
        it.addCategory(Intent.CATEGORY_OPENABLE)
        it.type = "audio/*"
        it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(it, audioReq)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val u = d?.data
        if (r == audioReq && res == RESULT_OK && u != null) {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            Store.p(this).edit().putString("audio", u.toString()).apply()
            render()
        }
    }
}
