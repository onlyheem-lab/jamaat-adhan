package com.heem.jamaatadhan

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.animation.ValueAnimator
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.*

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val GOLD = Color.parseColor("#D4AF37")
val PARCH = Color.parseColor("#F3E5C0")
val MUTED = Color.parseColor("#8FB5A3")
val RED = Color.parseColor("#E8836B")
val GREEN = Color.parseColor("#8FE3A0")

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.tv(t: String, size: Float, color: Int = PARCH, bold: Boolean = false, serif: Boolean = false) =
    TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        typeface = Typeface.create(if (serif) Typeface.SERIF else Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

fun Context.chip(t: String, f: () -> Unit): TextView {
    val g = GlassDrawable(resources.displayMetrics.density, 0f, Color.WHITE, 34)
    return tv(t, 13f, PARCH).apply {
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(11), dp(14), dp(11))
        background = g
        setOnClickListener { f() }
        glassPress(g, 1.05f)
    }
}

fun Context.row(vararg v: View): LinearLayout {
    val r = LinearLayout(this)
    r.gravity = Gravity.CENTER_VERTICAL
    for ((i, x) in v.withIndex()) {
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        if (i > 0) lp.leftMargin = dp(10)
        r.addView(x, lp)
    }
    r.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
    return r
}

fun Context.cardView(hi: Boolean): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.background = GlassDrawable(resources.displayMetrics.density, 22f, Color.parseColor("#1F6A53"),
        if (hi) 175 else 150, if (hi) Color.parseColor("#FFE08A") else Color.WHITE, if (hi) 240 else 150)
    l.setPadding(dp(18), dp(16), dp(18), dp(16))
    l.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
    l.isClickable = true
    l.foreground = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#22FFFFFF")), null,
        GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(Color.WHITE) })
    l.pressable(0.975f)
    return l
}

// Faint eight-pointed-star (khatam) pattern over a deep green gradient
class PatternBg(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val bg = Paint()
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * d
        color = Color.parseColor("#1AD4AF37")
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        bg.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.parseColor("#05201A"), Color.parseColor("#0A382C"), Color.parseColor("#041812")),
            null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, bg)
        val t = 56 * d
        val r = 20 * d
        var y = 0f
        while (y < h + t) {
            var x = 0f
            while (x < w + t) {
                cv.save()
                cv.translate(x, y)
                cv.drawRect(-r, -r, r, r, ln)
                cv.rotate(45f)
                cv.drawRect(-r, -r, r, r, ln)
                cv.drawCircle(0f, 0f, r * 0.5f, ln)
                cv.restore()
                cv.save()
                cv.translate(x + t / 2, y + t / 2)
                cv.rotate(45f)
                cv.drawRect(-r * 0.3f, -r * 0.3f, r * 0.3f, r * 0.3f, ln)
                cv.restore()
                x += t
            }
            y += t
        }
    }
}

fun tsec(): Float = (System.nanoTime() / 1_000_000L % 3_600_000L) / 1000f

// Squish on touch, springy bounce back
fun View.pressable(scale: Float = 0.96f, haptic: Boolean = false) {
    isClickable = true
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (haptic) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                v.animate().setStartDelay(0).scaleX(scale).scaleY(scale).setDuration(110)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(420)
                    .setInterpolator(OvershootInterpolator(3f)).start()
        }
        false
    }
}

// Root layout: spawns a golden ripple + sparks wherever the screen is touched
class Root(c: Context, private val fx: Floaters) : FrameLayout(c) {
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) fx.burst(ev.x, ev.y)
        return super.dispatchTouchEvent(ev)
    }
}

// Floating layer. back = big slowly-turning outlined stars; front = rising golden sparkles + touch bursts
class Floaters(c: Context, private val front: Boolean) : View(c) {
    private class Burst(val x: Float, val y: Float, val t0: Long)
    private val d = c.resources.displayMetrics.density
    private val n = if (front) 26 else 8
    private val rnd = java.util.Random(if (front) 7L else 3L)
    private val px = FloatArray(n) { rnd.nextFloat() }
    private val off = FloatArray(n) { rnd.nextFloat() }
    private val ph = FloatArray(n) { rnd.nextFloat() * 6.28f }
    private val spd = FloatArray(n) { (if (front) 0.012f else 0.006f) + rnd.nextFloat() * (if (front) 0.02f else 0.008f) }
    private val sz = FloatArray(n) { if (front) 1.2f + rnd.nextFloat() * 2.2f else 14f + rnd.nextFloat() * 26f }
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d; color = GOLD }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFE9A8") }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = GOLD }
    private val bursts = ArrayList<Burst>()
    private var vis = false

    fun burst(x: Float, y: Float) { bursts.add(Burst(x, y, System.nanoTime())) }

    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        vis = v == VISIBLE
        if (vis) postInvalidateOnAnimation()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = tsec()
        for (i in 0 until n) {
            val s = sz[i] * d
            val prog = (t * spd[i] + off[i]) % 1f
            val y = h + s * 2 - prog * (h + s * 4)
            val x = px[i] * w + sin(t * 0.6f + ph[i]) * 18 * d
            if (front) {
                val tw = 0.5f + 0.5f * sin(t * 2.2f + ph[i])
                dot.alpha = (30 + 150 * tw).toInt()
                cv.drawCircle(x, y, s * (0.7f + 0.5f * tw), dot)
                dot.alpha = (16 * tw).toInt()
                cv.drawCircle(x, y, s * 3.4f, dot)
            } else {
                ln.alpha = (30 + 24 * sin(t * 0.8f + ph[i])).toInt()
                cv.save()
                cv.translate(x, y)
                cv.rotate(t * (if (i % 2 == 0) 9f else -9f) + ph[i] * 20f)
                cv.drawRect(-s / 2, -s / 2, s / 2, s / 2, ln)
                cv.rotate(45f)
                cv.drawRect(-s / 2, -s / 2, s / 2, s / 2, ln)
                cv.restore()
            }
        }
        val now = System.nanoTime()
        val iter = bursts.iterator()
        while (iter.hasNext()) {
            val b = iter.next()
            val p = (now - b.t0) / 900_000_000f
            if (p >= 1f) { iter.remove(); continue }
            val e = 1f - (1f - p) * (1f - p)
            ring.alpha = ((1f - p) * 200).toInt()
            ring.strokeWidth = (2.5f * (1f - p) + 0.6f) * d
            cv.drawCircle(b.x, b.y, 64 * d * e, ring)
            for (k in 0 until 8) {
                val a = k * Math.PI / 4 + p * 0.6
                val rr = 50 * d * e
                dot.alpha = ((1f - p) * 230).toInt()
                cv.drawCircle(b.x + (cos(a) * rr).toFloat(), b.y + (sin(a) * rr).toFloat(), 3 * d * (1f - p) + 0.5f * d, dot)
            }
        }
        if (vis) postInvalidateOnAnimation()
    }
}

// Bobbing crescent moon with a glowing halo and a twinkling star
class Moon(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private var vis = false
    private val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GOLD }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(0f, 0f, 40 * d, Color.argb(80, 212, 175, 55), Color.TRANSPARENT, Shader.TileMode.CLAMP)
    }
    private val moon = Path().apply {
        addCircle(0f, 0f, 17 * d, Path.Direction.CW)
        val cut = Path()
        cut.addCircle(7 * d, -4 * d, 14.5f * d, Path.Direction.CW)
        op(cut, Path.Op.DIFFERENCE)
    }
    private val star = Path().apply {
        moveTo(0f, -10 * d); lineTo(2.5f * d, -2.5f * d); lineTo(10 * d, 0f); lineTo(2.5f * d, 2.5f * d)
        lineTo(0f, 10 * d); lineTo(-2.5f * d, 2.5f * d); lineTo(-10 * d, 0f); lineTo(-2.5f * d, -2.5f * d); close()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (76 * d).toInt())

    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        vis = v == VISIBLE
        if (vis) postInvalidateOnAnimation()
    }

    override fun onDraw(cv: Canvas) {
        val t = tsec()
        val cx = width / 2f
        val cy = height / 2f + 4 * d * sin(t * 1.2f)
        val pulse = 1f + 0.08f * sin(t * 2f)
        cv.save()
        cv.translate(cx, cy)
        cv.scale(pulse, pulse)
        cv.drawCircle(0f, 0f, 40 * d, halo)
        cv.restore()
        cv.save()
        cv.translate(cx - 4 * d, cy)
        cv.rotate(4f * sin(t * 0.9f))
        cv.drawPath(moon, gold)
        cv.restore()
        val tw = 0.65f + 0.35f * sin(t * 3f)
        cv.save()
        cv.translate(cx + 26 * d, cy - 14 * d)
        cv.scale(tw, tw)
        cv.rotate(t * 20f)
        gold.alpha = (140 + 115 * tw).toInt().coerceIn(0, 255)
        cv.drawPath(star, gold)
        gold.alpha = 255
        cv.restore()
        if (vis) postInvalidateOnAnimation()
    }
}

// Mihrab-arch card: glowing border, smooth progress with a shimmer and a glowing knob
class Hero(c: Context) : View(c) {
    var title = ""
    var sub = ""
    var next = ""
    var warn = ""
    var progress = 0f
    private var shown = -1f
    private var vis = false
    private val d = c.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = GOLD; strokeWidth = 2.2f * d }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.parseColor("#88D4AF37"); strokeWidth = 1f * d }
    private val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GOLD }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.SERIF }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#33D4AF37"); strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GOLD; strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFF3C4"); strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 255, 230, 140) }
    private val p1 = Path()
    private val p2 = Path()

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (256 * d).toInt())

    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        vis = v == VISIBLE
        if (vis) postInvalidateOnAnimation()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val m = 4 * d
        val k = 9 * d
        fill.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.parseColor("#1C6350"), Color.parseColor("#0A2A22"), Shader.TileMode.CLAMP)
        p1.reset()
        p1.addRoundRect(RectF(m, m, w - m, h - m),
            floatArrayOf(120 * d, 120 * d, 120 * d, 120 * d, 26 * d, 26 * d, 26 * d, 26 * d), Path.Direction.CW)
        p2.reset()
        p2.addRoundRect(RectF(m + k, m + k, w - m - k, h - m - k),
            floatArrayOf(110 * d, 110 * d, 110 * d, 110 * d, 18 * d, 18 * d, 18 * d, 18 * d), Path.Direction.CW)
    }

    private fun text(cv: Canvas, s: String, y: Float, sp: Float, col: Int, maxW: Float, bold: Boolean = false) {
        tp.color = col
        tp.typeface = if (bold) Typeface.create(Typeface.SERIF, Typeface.BOLD) else Typeface.SERIF
        var size = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)
        tp.textSize = size
        while (tp.measureText(s) > maxW && size > 20f) { size -= 1f; tp.textSize = size }
        cv.drawText(s, width / 2f, y, tp)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val t = tsec()
        outer.alpha = (170 + 85 * sin(t * 1.6f)).toInt().coerceIn(0, 255)
        cv.drawPath(p1, fill)
        cv.drawPath(p1, outer)
        cv.drawPath(p2, inner)

        val cx = w / 2
        val oy = 38 * d
        val s = 1f + 0.18f * sin(t * 2f)
        val dia = Path()
        dia.moveTo(cx, oy - 8 * d * s); dia.lineTo(cx + 6 * d * s, oy); dia.lineTo(cx, oy + 8 * d * s); dia.lineTo(cx - 6 * d * s, oy); dia.close()
        cv.drawPath(dia, gold)
        cv.drawLine(cx - 56 * d, oy, cx - 16 * d, oy, inner)
        cv.drawLine(cx + 16 * d, oy, cx + 56 * d, oy, inner)

        text(cv, title, 90 * d, 24f, GOLD, w - 80 * d, true)
        text(cv, sub, 124 * d, 16f, PARCH, w - 70 * d)

        if (shown < 0f) shown = progress else shown += (progress - shown) * 0.08f
        val bx0 = w * 0.18f
        val bx1 = w * 0.82f
        val by = 150 * d
        cv.drawLine(bx0, by, bx1, by, track)
        if (shown > 0.01f) {
            val len = (bx1 - bx0) * shown
            cv.drawLine(bx0, by, bx0 + len, by, bar)
            val sx = bx0 + len * ((t * 0.5f) % 1f)
            cv.drawLine(max(bx0, sx - 14 * d), by, min(bx0 + len, sx + 14 * d), by, shine)
            cv.drawCircle(bx0 + len, by, 9 * d, glow)
            cv.drawCircle(bx0 + len, by, 4.5f * d, gold)
        }
        text(cv, next, 184 * d, 13f, MUTED, w - 50 * d)
        if (warn.isNotEmpty()) text(cv, warn, 216 * d, 13f, RED, w - 50 * d, true)
        if (vis) postInvalidateOnAnimation()
    }
}

fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

// "Liquid glass": translucent tinted body, soft top gloss, bright diagonal rim and an inner glint
class GlassDrawable(
    private val d: Float,
    private val radiusDp: Float,          // <= 0 means a full pill
    private val baseColor: Int,
    private val baseAlpha: Int,
    private val rimColor: Int = Color.WHITE,
    private val rimAlpha: Int = 230
) : Drawable() {
    var press = 0f
        set(v) { field = v; invalidateSelf() }
    private var a = 255
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d }
    private val glint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * d }
    private val r = RectF()
    private val inner = RectF()

    override fun onBoundsChange(b: Rect) {
        r.set(b.left + 0.6f * d, b.top + 0.6f * d, b.right - 0.6f * d, b.bottom - 0.6f * d)
        if (r.width() <= 0f || r.height() <= 0f) return
        body.shader = LinearGradient(0f, r.top, 0f, r.bottom, withA(baseColor, baseAlpha), withA(baseColor, (baseAlpha * 0.65f).toInt()), Shader.TileMode.CLAMP)
        gloss.shader = LinearGradient(0f, r.top, 0f, r.bottom,
            intArrayOf(withA(Color.WHITE, 80), withA(Color.WHITE, 10), withA(Color.WHITE, 0), withA(Color.WHITE, 26)),
            floatArrayOf(0f, 0.45f, 0.75f, 1f), Shader.TileMode.CLAMP)
        rim.shader = LinearGradient(r.left, r.top, r.right, r.bottom,
            intArrayOf(withA(rimColor, rimAlpha), withA(rimColor, 40), withA(rimColor, 30), withA(rimColor, rimAlpha * 2 / 3)),
            floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP)
        glint.shader = LinearGradient(0f, r.top, 0f, r.top + r.height() * 0.5f, withA(Color.WHITE, 150), withA(Color.WHITE, 0), Shader.TileMode.CLAMP)
    }

    override fun draw(cv: Canvas) {
        if (body.shader == null) return
        val mn = min(r.width(), r.height())
        val rad = if (radiusDp <= 0f) mn / 2 else min(radiusDp * d, mn / 2)
        body.alpha = (a * (0.82f + 0.18f * press)).toInt().coerceIn(0, 255)
        gloss.alpha = (a * (0.7f + 0.3f * press)).toInt().coerceIn(0, 255)
        rim.alpha = a
        glint.alpha = (a * (0.6f + 0.4f * press)).toInt().coerceIn(0, 255)
        cv.drawRoundRect(r, rad, rad, body)
        cv.drawRoundRect(r, rad, rad, gloss)
        inner.set(r.left + 1.6f * d, r.top + 1.6f * d, r.right - 1.6f * d, r.bottom - 1.6f * d)
        val ir = max(0f, rad - 1.6f * d)
        cv.drawRoundRect(inner, ir, ir, glint)
        cv.drawRoundRect(r, rad, rad, rim)
    }

    override fun setAlpha(alpha: Int) { a = alpha; invalidateSelf() }
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

// Glass buttons swell when touched (like iOS 26) and spring back
fun View.glassPress(g: GlassDrawable, swell: Float = 1.05f) {
    isClickable = true
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                v.animate().setStartDelay(0).scaleX(swell).scaleY(swell).setDuration(160)
                    .setInterpolator(DecelerateInterpolator()).start()
                ValueAnimator.ofFloat(g.press, 1f).apply {
                    duration = 180
                    addUpdateListener { g.press = it.animatedValue as Float }
                }.start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(520)
                    .setInterpolator(OvershootInterpolator(4f)).start()
                ValueAnimator.ofFloat(g.press, 0f).apply {
                    duration = 300
                    addUpdateListener { g.press = it.animatedValue as Float }
                }.start()
            }
        }
        false
    }
}

// Liquid-glass toggle: glass track that fills with gold, and a bright glass thumb that stretches while pressed
class GlassSwitch(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val trackOff = GlassDrawable(d, 0f, Color.WHITE, 34)
    private val trackOn = GlassDrawable(d, 0f, GOLD, 205, Color.parseColor("#FFF3C4"), 240)
    private val thumb = GlassDrawable(d, 0f, Color.WHITE, 240, Color.WHITE, 255)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val rr = RectF()
    private val tw0 = 36 * d
    private val inset = 3 * d
    private val slop = ViewConfiguration.get(c).scaledTouchSlop
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null
    private var pos = 0f
    private var press = 0f
    private var anim: ValueAnimator? = null
    private var downX = 0f
    private var startPos = 0f
    private var dragging = false

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((62 * d).toInt(), (34 * d).toInt())

    private fun range() = width - 2 * inset - tw0

    fun setChecked(v: Boolean, animate: Boolean) {
        checked = v
        anim?.cancel()
        val target = if (v) 1f else 0f
        if (!animate) { pos = target; invalidate(); return }
        anim = ValueAnimator.ofFloat(pos, target).apply {
            duration = 380
            interpolator = OvershootInterpolator(1.4f)
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun setPress(to: Float) {
        ValueAnimator.ofFloat(press, to).apply {
            duration = 200
            addUpdateListener { press = it.animatedValue as Float; thumb.press = press; invalidate() }
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; startPos = pos; dragging = false
                anim?.cancel()
                setPress(1f)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                if (!dragging && abs(dx) > slop) dragging = true
                if (dragging) { pos = (startPos + dx / range()).coerceIn(0f, 1f); invalidate() }
                return true
            }
            MotionEvent.ACTION_UP -> {
                setPress(0f)
                val nv = if (dragging) pos > 0.5f else !checked
                val changed = nv != checked
                setChecked(nv, true)
                if (changed) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onChange?.invoke(nv)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                setPress(0f)
                setChecked(checked, true)
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(cv: Canvas) {
        val w = width
        val h = height
        val p = pos.coerceIn(0f, 1f)
        trackOff.setBounds(0, 0, w, h)
        trackOff.setAlpha(((1f - p) * 255).toInt())
        trackOff.draw(cv)
        trackOn.setBounds(0, 0, w, h)
        trackOn.setAlpha((p * 255).toInt())
        trackOn.draw(cv)

        val extra = 8 * d * press
        val left = inset + range() * pos - extra * p
        val right = left + tw0 + extra
        val top = inset
        val bottom = h - inset
        for (i in 3 downTo 1) {
            shadow.alpha = 16
            rr.set(left - i * 0.6f * d, top + 0.8f * d, right + i * 0.6f * d, bottom + 0.6f * d + i * 0.5f * d)
            cv.drawRoundRect(rr, rr.height() / 2, rr.height() / 2, shadow)
        }
        thumb.setBounds(left.toInt(), top.toInt(), right.toInt(), bottom.toInt())
        thumb.draw(cv)
    }
}
