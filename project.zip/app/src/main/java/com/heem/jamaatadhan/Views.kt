package com.heem.jamaatadhan

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val GOLD = Color.parseColor("#D4AF37")
val PARCH = Color.parseColor("#F3E5C0")
val MUTED = Color.parseColor("#8FB5A3")
val RED = Color.parseColor("#E8836B")
val GREEN = Color.parseColor("#8FE3A0")

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.tv(t: String, size: Float, color: Int = PARCH, bold: Boolean = false, serif: Boolean = false) =
    TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        typeface = Typeface.create(if (serif) Typeface.SERIF else Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

fun Context.chip(t: String, f: () -> Unit): TextView {
    val r = dp(22).toFloat()
    val g = GradientDrawable().apply { cornerRadius = r; setStroke(dp(1), GOLD); setColor(Color.TRANSPARENT) }
    val mask = GradientDrawable().apply { cornerRadius = r; setColor(Color.WHITE) }
    return tv(t, 13f, GOLD).apply {
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(11), dp(12), dp(11))
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#44D4AF37")), g, mask)
        setOnClickListener { f() }
    }
}

fun Context.row(vararg v: View): LinearLayout {
    val r = LinearLayout(this)
    r.gravity = Gravity.CENTER_VERTICAL
    for ((i, x) in v.withIndex()) {
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        if (i > 0) lp.leftMargin = dp(10)
        r.addView(x, lp)
    }
    r.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
    return r
}

fun Context.cardView(hi: Boolean): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#16493B"), Color.parseColor("#0B2D25")))
    g.cornerRadius = dp(20).toFloat()
    g.setStroke(dp(if (hi) 2 else 1), if (hi) GOLD else Color.parseColor("#66D4AF37"))
    l.background = g
    l.setPadding(dp(18), dp(16), dp(18), dp(16))
    l.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
    return l
}

// Faint eight-pointed-star (khatam) pattern over a deep green gradient
class PatternBg(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val bg = Paint()
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * d
        color = Color.parseColor("#1AD4AF37")
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        bg.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.parseColor("#05201A"), Color.parseColor("#0A382C"), Color.parseColor("#041812")),
            null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, bg)
        val t = 56 * d
        val r = 20 * d
        var y = 0f
        while (y < h + t) {
            var x = 0f
            while (x < w + t) {
                cv.save()
                cv.translate(x, y)
                cv.drawRect(-r, -r, r, r, ln)
                cv.rotate(45f)
                cv.drawRect(-r, -r, r, r, ln)
                cv.drawCircle(0f, 0f, r * 0.5f, ln)
                cv.restore()
                cv.save()
                cv.translate(x + t / 2, y + t / 2)
                cv.rotate(45f)
                cv.drawRect(-r * 0.3f, -r * 0.3f, r * 0.3f, r * 0.3f, ln)
                cv.restore()
                x += t
            }
            y += t
        }
    }
}

// Mihrab-arch card that shows the current waqt and a progress line
class Hero(c: Context) : View(c) {
    var title = ""
    var sub = ""
    var next = ""
    var warn = ""
    var progress = 0f
    private val d = c.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = GOLD; strokeWidth = 2.2f * d }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.parseColor("#88D4AF37"); strokeWidth = 1f * d }
    private val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GOLD }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.SERIF }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#33D4AF37"); strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GOLD; strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (256 * d).toInt())

    private fun text(cv: Canvas, s: String, y: Float, sp: Float, col: Int, maxW: Float, bold: Boolean = false) {
        tp.color = col
        tp.typeface = if (bold) Typeface.create(Typeface.SERIF, Typeface.BOLD) else Typeface.SERIF
        var size = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)
        tp.textSize = size
        while (tp.measureText(s) > maxW && size > 20f) { size -= 1f; tp.textSize = size }
        cv.drawText(s, width / 2f, y, tp)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 4 * d
        fill.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#1C6350"), Color.parseColor("#0A2A22"), Shader.TileMode.CLAMP)
        val outerR = floatArrayOf(120 * d, 120 * d, 120 * d, 120 * d, 26 * d, 26 * d, 26 * d, 26 * d)
        val p = Path()
        p.addRoundRect(RectF(m, m, w - m, h - m), outerR, Path.Direction.CW)
        cv.drawPath(p, fill)
        cv.drawPath(p, outer)
        val k = 9 * d
        val innerR = floatArrayOf(110 * d, 110 * d, 110 * d, 110 * d, 18 * d, 18 * d, 18 * d, 18 * d)
        val p2 = Path()
        p2.addRoundRect(RectF(m + k, m + k, w - m - k, h - m - k), innerR, Path.Direction.CW)
        cv.drawPath(p2, inner)

        val cx = w / 2
        val oy = 38 * d
        val dia = Path()
        dia.moveTo(cx, oy - 8 * d); dia.lineTo(cx + 6 * d, oy); dia.lineTo(cx, oy + 8 * d); dia.lineTo(cx - 6 * d, oy); dia.close()
        cv.drawPath(dia, gold)
        cv.drawLine(cx - 56 * d, oy, cx - 16 * d, oy, inner)
        cv.drawLine(cx + 16 * d, oy, cx + 56 * d, oy, inner)

        text(cv, title, 90 * d, 24f, GOLD, w - 80 * d, true)
        text(cv, sub, 124 * d, 16f, PARCH, w - 70 * d)
        val bx0 = w * 0.18f
        val bx1 = w * 0.82f
        val by = 150 * d
        cv.drawLine(bx0, by, bx1, by, track)
        if (progress > 0.01f) cv.drawLine(bx0, by, bx0 + (bx1 - bx0) * progress, by, bar)
        text(cv, next, 184 * d, 13f, MUTED, w - 50 * d)
        if (warn.isNotEmpty()) text(cv, warn, 216 * d, 13f, RED, w - 50 * d, true)
    }
}
