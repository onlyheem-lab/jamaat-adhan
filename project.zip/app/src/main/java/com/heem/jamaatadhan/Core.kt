package com.heem.jamaatadhan

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.*
import java.util.Calendar

val NAMES = listOf("ফজর", "জোহর", "আসর", "মাগরিব", "ইশা")
val DEF_J = intArrayOf(5 * 60, 13 * 60 + 30, 16 * 60 + 30, 18 * 60 + 10, 20 * 60)
val DEF_G = intArrayOf(15, 30, 15, 3, 15)

object Store {
    fun p(c: Context): SharedPreferences = c.getSharedPreferences("jamaat", Context.MODE_PRIVATE)
    fun jamaat(c: Context, i: Int) = p(c).getInt("j$i", DEF_J[i])
    fun gap(c: Context, i: Int) = p(c).getInt("g$i", DEF_G[i])
    fun enabled(c: Context, i: Int) = p(c).getBoolean("e$i", false)
    fun audio(c: Context): String? = p(c).getString("audio", null)
}

object Scheduler {
    // আজানের সময় = জামাতের সময় - gap
    fun triggerTime(c: Context, i: Int): Long {
        val j = Store.jamaat(c, i)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, j / 60)
        cal.set(Calendar.MINUTE, j % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.MINUTE, -Store.gap(c, i))
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun pending(c: Context, i: Int): PendingIntent {
        val intent = Intent(c, AlarmReceiver::class.java).putExtra("i", i)
        return PendingIntent.getBroadcast(c, i, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun canExact(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        return (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
    }

    fun scheduleAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0..4) {
            try {
                if (Store.enabled(c, i)) {
                    val show = PendingIntent.getActivity(c, 100 + i, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                    am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerTime(c, i), show), pending(c, i))
                } else {
                    am.cancel(pending(c, i))
                }
            } catch (e: SecurityException) {
                // permission missing: the app shows a button to grant it
            }
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val i = intent.getIntExtra("i", -1)
        try {
            c.startForegroundService(Intent(c, AdhanService::class.java).putExtra("i", i))
        } catch (e: Exception) { /* ignore */ }
        Scheduler.scheduleAll(c) // পরের দিনের জন্য আবার সেট
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        Scheduler.scheduleAll(c)
    }
}

class AdhanService : Service() {
    private var player: MediaPlayer? = null
    private var oldVol = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        val i = intent?.getIntExtra("i", -1) ?: -1
        val name = if (i in 0..4) NAMES[i] else "আজান"
        val ch = "adhan"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Adhan", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, AdhanService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("$name এর আজান")
            .setContentText("থামাতে Stop চাপো")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)

        val am = getSystemService(AudioManager::class.java)
        if (oldVol < 0) oldVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)

        player?.release()
        val uri = Store.audio(this)?.let { Uri.parse(it) } ?: Settings.System.DEFAULT_ALARM_ALERT_URI
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setWakeMode(this@AdhanService, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(this@AdhanService, uri)
                setOnCompletionListener { stopSelf() }
                prepare()
                start()
            }
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        player?.release()
        player = null
        if (oldVol >= 0) {
            getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, oldVol, 0)
        }
        super.onDestroy()
    }
}

